package com.example.client;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class PointOfInterest {
    public final String name;
    public final int x, z;
    private final List<String> rawMessages;
    private List<class_2561> parsedMessages;
    private final List<Integer> delaysTicks;

    public PointOfInterest(String name, int x, int z, List<String> messages) {
        this.name = name;
        this.x = x;
        this.z = z;
        this.rawMessages = messages;
        this.parsedMessages = null;
        this.delaysTicks = new ArrayList<>();

        for (String msg : messages) {
            int wordCount = msg.trim().isEmpty() ? 0 : msg.trim().split("\\s+").length;
            int dotCount = countChar(msg, '.');
            int commaCount = countChar(msg, ',');
            int delay = 40 + wordCount * 4 + dotCount * 20 + commaCount * 10;
            delaysTicks.add(delay);
        }
    }

    private int countChar(String str, char ch) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == ch) count++;
        }
        return count;
    }

    public List<class_2561> getParsedMessages() {
        if (parsedMessages == null) {
            parsedMessages = new ArrayList<>();
            for (String raw : rawMessages) {
                parsedMessages.add(parseMessage(raw));
            }
        }
        return parsedMessages;
    }

    public int getMessageDelay(int index) {
        return (index >= 0 && index < delaysTicks.size()) ? delaysTicks.get(index) : 60;
    }

    private class_2561 parseMessage(String raw) {
        class_5250 result = class_2561.method_43470("");

        Pattern tokenizer = Pattern.compile(
                "\\[(?:[^\\]]*)\\]\\[(?:https?://[^\\]]+)\\]" +   // [текст][url]
                        "|\\[(?:[^\\]]*)\\]\\((?:[^\\)]+)\\)" +           // [текст](url)
                        "|\\[(?:https?://[^\\]]+)\\]" +                   // [url]
                        "|\\*[^*]+\\*" +                                  // *важное*
                        "|\\b\\d{4}\\b"                                   // год
        );

        Matcher m = tokenizer.matcher(raw);
        int lastEnd = 0;
        while (m.find()) {
            if (m.start() > lastEnd) {
                String plain = raw.substring(lastEnd, m.start());
                result = result.method_10852(class_2561.method_43470(plain));
            }

            String token = m.group();
            if (token.startsWith("[")) {
                if (token.contains("][")) {
                    int split = token.indexOf("][");
                    String text = token.substring(1, split);
                    String url = token.substring(split+2, token.length()-1);
                    result = result.method_10852(makeLink(text, url));
                } else if (token.contains("](")) {
                    int split = token.indexOf("](");
                    String text = token.substring(1, split);
                    String url = token.substring(split+2, token.length()-1);
                    result = result.method_10852(makeLink(text, url));
                } else {
                    String url = token.substring(1, token.length()-1);
                    result = result.method_10852(makeLink(url, url));
                }
            } else if (token.startsWith("*") && token.endsWith("*")) {

                String text = token.substring(1, token.length()-1);
                result = result.method_10852(class_2561.method_43470(text)
                        .method_27694(style -> style.method_10977(class_124.field_1054).method_10982(true)));
            } else {

                result = result.method_10852(class_2561.method_43470(token)
                        .method_27694(style -> style.method_10977(class_124.field_1054)));
            }
            lastEnd = m.end();
        }
        if (lastEnd < raw.length()) {
            result = result.method_10852(class_2561.method_43470(raw.substring(lastEnd)));
        }

        return result;
    }

    private class_5250 makeLink(String text, String url) {
        class_5250 link = class_2561.method_43470(text)
                .method_27694(style -> style
                        .method_10977(class_124.field_1078)
                        .method_30938(true));
        try {
            URI uri = URI.create(url);
            link = link.method_27694(style -> style.method_10958(new class_2558.class_10608(uri)));
        } catch (IllegalArgumentException ignored) {}
        return link;
    }
}